﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeTasks
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            DateTime instantDate = DateTime.Now;
            Console.WriteLine("Current Month:");
            Console.WriteLine(instantDate.ToString("MMMM"));

            Console.WriteLine("3 Day before from now:");
            DateTime threeDaysBefore = instantDate.AddDays(-3);
            Console.WriteLine(threeDaysBefore.ToString("dddd"));

            Console.WriteLine("Present time in 12 hours format:");
            Console.WriteLine(DateTime.Now.ToString("hh:mm tt"));

            Console.ReadLine();
        }
    }
}
/*
 Write a C# program to perform below operation.

Print the current month of the day
Print the previous of 3 day from current date
Print the 12 hours’ time of now followed by am , pm
 */