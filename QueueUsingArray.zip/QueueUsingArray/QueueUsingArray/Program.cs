﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueUsingArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int [] Quearray;
            int max = 0;
            int min = 0;


            void Queue(int size)
            {
                Quearray = new int[size];
                max = size;
            }

            void Push(int a)
            {
                Quearray[max-1] = a;
                max--;
                
                

            }
            void Peek()
            {
                Console.WriteLine(Quearray[0]);
            }
            void Pop()
            {
                Quearray[min] = 0;
                min++;

            }

            Queue(6);
            Push(2);
            Push(3);
            Push(3);
            Push(3);
            Push(5);
            Push(5);
            Pop();
            Pop();

            Peek();
            

            foreach(int a in Quearray)
            {
                Console.WriteLine(a);
            }
            Console.Read();
           
            



        }
    }
}
