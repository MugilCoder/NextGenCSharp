﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public enum Operation 
    {
        Add,
        Subtract,
        Multiply,
        Divide,
        None
    }
    class MainExecution
    {
        static void Main(string[] args)
        {
            string input = String.Empty;
            Console.WriteLine("Enter the first integer input:");
            input = Console.ReadLine();
            int firstInput = 0;

            while (int.TryParse(input, out firstInput) == false)
            {

                Console.WriteLine("Invalid input!");
                Console.WriteLine("Enter the first integer input:");
                input = Console.ReadLine();
            }

            Console.WriteLine("Enter the Second integer input:");
            input = Console.ReadLine();
            int secondInput = 0;

            while (int.TryParse(input, out secondInput) == false)
            {
                Console.WriteLine("Invalid input!");
                Console.WriteLine("Enter the Second integer input:");
                input = Console.ReadLine();
            }

            Console.WriteLine("Enter your choice:\n1.Addition\n2.Subtration\n3.Multiplication\n4.Division");
            input = Console.ReadLine();
            int userChoice = 0;
            while (int.TryParse(input, out userChoice) == false || int.Parse(input) > 4 || int.Parse(input) < 1)
            {
                if (int.TryParse(input, out userChoice) == false)
                {
                    Console.WriteLine("Invalid Input!");
                }
                else
                {
                    Console.WriteLine("Invalid Choice!");

                }
                Console.WriteLine("Enter your choice:\n1.Addition\n2.Subtration\n3.Multiplication\n4.Division");
                input = Console.ReadLine();
            }
            try
            {

                Operation operationChoice;
                switch (userChoice)
                {
                    case 1:
                        operationChoice = Operation.Add;
                        break;


                    case 2:
                        operationChoice = Operation.Subtract;
                        break;


                    case 3:
                        operationChoice = Operation.Multiply;
                        break;


                    case 4:
                        operationChoice = Operation.Divide;
                        break;

                    default:
                        operationChoice = Operation.None;
                        break;
                }

                int output;
                switch (operationChoice)
                {
                    case Operation.Add:
                        output = firstInput + secondInput;
                        Console.WriteLine($"Addition result = {output}");
                        break;


                    case Operation.Subtract:
                        output = firstInput - secondInput;
                        Console.WriteLine($"Subtraction result = {output}");
                        break;


                    case Operation.Multiply:
                        output = firstInput * secondInput;
                        Console.WriteLine($"Multiplication result = {output}");
                        break;


                    case Operation.Divide:
                        output = firstInput / secondInput;
                        Console.WriteLine($"Division result = {output}");
                        break;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Message = {ex.Message}");
            }

            Console.ReadLine();
        }
    }
}
