﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentSystem
{
    class Appointment
    {
        public int AppointmentId { get; }
        private static int _appointmentId = 1000;
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public DateTime Date { get; set; }
        public string Problem { get; set; }

        public Appointment(int patientId, int doctorId, DateTime date, string problem) 
        {
            AppointmentId = _appointmentId;
            _appointmentId++;

            PatientId = patientId;
            DoctorId = doctorId;
            Date = date;
            Problem = problem;
        }
    }
}
