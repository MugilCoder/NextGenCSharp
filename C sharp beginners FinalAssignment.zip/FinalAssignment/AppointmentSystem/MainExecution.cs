﻿using System;
using System.Linq;
using System.Windows;

namespace AppointmentSystem
{

    class MainExecution
    {
        private static void DataAddedNotification() 
        {
            Console.WriteLine("---------------------------------------------------------");
            Console.WriteLine("Successfully added data!!");
            Console.WriteLine("---------------------------------------------------------");
        }

        private static bool displayMainMenu = false;
        static void Main(string[] args)
        {
            AppointmentManager.ShowPopup += DataAddedNotification;
            AppointmentManager.allDoctorDetails.Add(new Doctor("Nancy", "Anaesthesiology"));
            AppointmentManager.allDoctorDetails.Add(new Doctor("Andrew", "Cardiology"));
            AppointmentManager.allDoctorDetails.Add(new Doctor("Janet", "Diabetology"));
            AppointmentManager.allDoctorDetails.Add(new Doctor("Margaret", "Neonatology"));
            AppointmentManager.allDoctorDetails.Add(new Doctor("Steven", "Nephrology"));


            AppointmentManager.allPatientDetails.Add(new Patient("Robert", 40, 1, "welcome"));
            AppointmentManager.allPatientDetails.Add(new Patient("Laura", 36, 2, "welcome"));
            AppointmentManager.allPatientDetails.Add(new Patient("Anne", 42, 2, "welcome"));

            AppointmentManager.allAppointments.Add(new Appointment(100, 2, DateTime.Today, "Heart Problem"));
            AppointmentManager.allAppointments.Add(new Appointment(100, 5, DateTime.Today, "Spinal cord injury"));
            AppointmentManager.allAppointments.Add(new Appointment(101, 2, DateTime.Today, "Heart attack"));


            string tempInput = string.Empty;
            do
            {
                Console.WriteLine(">>>   Online Appointment System   <<<");
                Console.WriteLine("Main Menu\n  1.Login\n  2.Register");
                tempInput = Console.ReadLine();
                int menuChoice;
                while (int.TryParse(tempInput, out menuChoice) == false ||
                        (int.Parse(tempInput) != 1 && int.Parse(tempInput) != 2))
                {
                    if (int.TryParse(tempInput, out menuChoice) == false)
                    {
                        Console.WriteLine("Invalid Input!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid choice!");
                    }
                    Console.WriteLine("Main Menu\n  1.Login\n  2.Register");
                    tempInput = Console.ReadLine();
                }

                /// Login
                if (menuChoice == 1)
                {
                    Console.WriteLine("Enter your user name:");
                    string patientName = Console.ReadLine();

                    Console.WriteLine("Enter your password:");
                    string patientPassword = Console.ReadLine();

                    bool isValidCredential = AppointmentManager.ValidatePatient(patientName, patientPassword);

                    if (isValidCredential == true)
                    {
                        bool displayPatientMenu = false;

                        do
                        {
                            Console.WriteLine("Patient Menu\n  1.Book Appointment\n  2.View Appointment details\n  3.Edit my profile\n  4.Exit");
                            tempInput = Console.ReadLine();
                            int patientChoice;
                            while (int.TryParse(tempInput, out patientChoice) == false ||
                                    (int.Parse(tempInput) < 1 || int.Parse(tempInput) > 4))
                            {
                                if (int.TryParse(tempInput, out patientChoice) == false)
                                {
                                    Console.WriteLine("Invalid Input!");
                                }
                                else
                                {
                                    Console.WriteLine("Invalid choice!");
                                }
                                Console.WriteLine("Patient Menu\n  1.Book Appointment\n  2.View Appointment details\n  3.Edit my profile\n  4.Exit");
                                tempInput = Console.ReadLine();
                            }
                           
                            int patientId = AppointmentManager.allPatientDetails
                                    .Where(x => x.Name == patientName && x.Password == patientPassword)
                                    .Select(y => y.PatientId).First();
                            

                            switch (patientChoice)
                            {
                                case 1:
                                    
                                    displayPatientMenu = AppointmentManager.BookAppointment(patientId);

                                    break;
                                case 2:
                                    AppointmentManager.ViewAppointments(patientId);
                                    displayPatientMenu = true;
                                    break;
                                case 3:
                                    Patient editedPatient = AppointmentManager.EditPatientProfile(patientId);
                                    patientName = editedPatient.Name;
                                    patientPassword = editedPatient.Password;
                                    displayPatientMenu = true;
                                    break;
                                case 4:
                                    displayMainMenu = true;
                                    displayPatientMenu = false;
                                    break;
                            }
                        } while (displayPatientMenu);
                    }
                    else
                    {
                        Console.WriteLine("Sorry, your record is invalid. Please register your profile and log in again.");
                        displayMainMenu = true;
                    }
                }

                /// Register
                else if (menuChoice == 2)
                {

                    Console.WriteLine(">>>  New Account Creation <<<");
                    bool isAlreadyExist = false;
                    string name = string.Empty;
                    string password = string.Empty;
                    do
                    {
                        if (isAlreadyExist)
                        {
                            Console.WriteLine("Account already exist!!");
                        }
                        Console.WriteLine("Enter Name:");
                        name = Console.ReadLine();

                        Console.WriteLine("Enter Password:");
                        password = Console.ReadLine();

                        isAlreadyExist = AppointmentManager.allPatientDetails
                                .Where(x => x.Name == name && x.Password == password)
                                .Any();
                    } while (isAlreadyExist);

                    Console.WriteLine("Enter Age:");
                    tempInput = Console.ReadLine();
                    int age;
                    while (int.TryParse(tempInput, out age) == false || int.Parse(tempInput) <= 0)
                    {
                        if (int.TryParse(tempInput, out age) == false)
                        {
                            Console.WriteLine("Invalid Input!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Age!");
                        }
                        Console.WriteLine("Enter Age:");
                        tempInput = Console.ReadLine();
                    }

                    Console.WriteLine("Enter Gender choice:\n  1.Male\n  2.Female");
                    tempInput = Console.ReadLine();
                    int genderChoice;
                    while (int.TryParse(tempInput, out genderChoice) == false ||
                        (int.Parse(tempInput) != 1 && int.Parse(tempInput) != 2))
                    {
                        if (int.TryParse(tempInput, out genderChoice) == false)
                        {
                            Console.WriteLine("Invalid Input!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid choice!");
                        }
                        Console.WriteLine("Enter Gender choice:\n  1.Male\n  2.Female");
                        tempInput = Console.ReadLine();
                    }
                    AppointmentManager.allPatientDetails.Add(new Patient(name, age, genderChoice, password));
                    displayMainMenu = true;
                }
            } while (displayMainMenu == true);
            Console.ReadLine();
        }        

    }

}


