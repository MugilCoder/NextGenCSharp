﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentSystem
{
    class Doctor
    {
        public int DoctorId { get;}

        private static int _doctorId = 1;
        public string Name { get; }
        public string Department { get; }

        public Doctor(string name, string department) 
        {
            DoctorId = _doctorId;
            _doctorId++;
            Name = name;
            Department = department;

        }

    }
}
