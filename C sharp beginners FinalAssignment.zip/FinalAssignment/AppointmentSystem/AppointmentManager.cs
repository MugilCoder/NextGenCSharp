﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentSystem
{
     class AppointmentManager
    {
        public delegate void Notify();
        public static event Notify ShowPopup;

        public static List<Doctor> allDoctorDetails = new List<Doctor>();
        public static List<Patient> allPatientDetails = new List<Patient>();
        public static List<Appointment> allAppointments = new List<Appointment>();
        public static bool ValidatePatient(string name, string password)
        {
            if (allPatientDetails.Any())
            {
                foreach (Patient eachPatient in allPatientDetails)
                {
                    if (eachPatient.Name.Equals(name) && eachPatient.Password.Equals(password))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        

        public static string CheckDoctorAvailability(int doctorId, int patientId)
        {
            DateTime appointmentDate = DateTime.Today;
            bool isDateFixed = false;
            do
            {
                int specificAppointmentCount = allAppointments.Count(x => x.DoctorId.Equals(doctorId)
                                            && x.Date.Equals(appointmentDate));

                if (specificAppointmentCount == 1)
                {

                    bool isSamePatient = allAppointments.Where(y => y.DoctorId == doctorId
                                            && y.PatientId == patientId
                                            && y.Date == appointmentDate).Any();

                    if (isSamePatient == true)
                    {
                        appointmentDate = appointmentDate.AddDays(1);
                        isDateFixed = false;
                    }
                    else
                    {
                        isDateFixed = true;
                    }


                }
                else if (specificAppointmentCount == 0)
                {
                    isDateFixed = true;
                }
                else if (specificAppointmentCount == 2)
                {
                    appointmentDate = appointmentDate.AddDays(1);
                    isDateFixed = false;
                }
            } while (!isDateFixed);

            return appointmentDate.ToShortDateString();
        }
        public static bool BookAppointment(int patientId)
        {
            Console.WriteLine("Select the department from the below List:");
            Console.WriteLine("  1.Anaesthesiology\n  2.Cardiology\n  3.Diabetology\n  4.Neonatology\n  5.Nephrology");
            string input = Console.ReadLine();
            int doctorId;  // handle exception
            while (int.TryParse(input, out doctorId) == false || int.Parse(input) > 5 || int.Parse(input) < 0)
            {
                if (int.TryParse(input, out doctorId) == false) 
                {
                    Console.WriteLine("Invalid Choice!");
                }
                else 
                {
                    Console.WriteLine("Invalid Input!");
                }
                Console.WriteLine("Select the department from the below List:");
                Console.WriteLine("  1.Anaesthesiology\n  2.Cardiology\n  3.Diabetology\n  4.Neonatology\n  5.Nephrology");
                input = Console.ReadLine();
            }

            string appointmentDate = CheckDoctorAvailability(doctorId, patientId);
            Console.WriteLine($"Appointment is confirmed for the date = {appointmentDate}.\n To book press “Y”, to cancel press “N”.");
            string choice = Console.ReadLine().ToUpper();
            while (!choice.Equals("Y") && !choice.Equals("N"))
            {
                Console.WriteLine("Invalid choice!");
                Console.WriteLine($"Appointment is confirmed for the date = {appointmentDate}.\n To book press “Y”, to cancel press “N”.");
                choice = Console.ReadLine().ToUpper();
            }
            if (choice.Equals("Y"))
            {


                Console.WriteLine("Enter your problem:");
                string problem = Console.ReadLine();
                allAppointments.Add(new Appointment(patientId, doctorId, DateTime.Parse(appointmentDate), problem));
                ShowPopup.Invoke();
            }
            return true;

        }
        public static void ViewAppointments(int patientId)
        {
            Console.WriteLine("------------------------------------------------------------");
            Console.WriteLine("\t\tAppointments History");

            foreach (Appointment eachAppointment in allAppointments)
            {
                if (eachAppointment.PatientId == patientId)
                {
                    Console.WriteLine("------------------------------------------------------------");
                    Console.WriteLine($"Appointment Id = {eachAppointment.AppointmentId}\n" +
                        $"Patient Id = {eachAppointment.PatientId}\nDoctor Id = {eachAppointment.DoctorId}\n" +
                        $"Appointment Date = {eachAppointment.Date.ToShortDateString()}\nProblem = {eachAppointment.Problem}");
                }
            }
        }
        public static Patient EditPatientProfile(int patientId)
        {
            Patient editedPatientObj = null;
            foreach (Patient eachPatient in allPatientDetails)
            {
                if (eachPatient.PatientId == patientId)
                {

                    Console.WriteLine("----------------------------------------------------------------");
                    Console.WriteLine("\t\tEdit Menu");
                    Console.WriteLine("----------------------------------------------------------------");
                    string tempInput = string.Empty;
                    bool isAlreadyExist = false;
                    string name = string.Empty;
                    string password = string.Empty;
                    do
                    {
                        if (isAlreadyExist)
                        {
                            Console.WriteLine("Account already exist with same name and password!!");
                        }
                        Console.WriteLine("Enter Name:");
                        name = Console.ReadLine();

                        Console.WriteLine("Enter Password:");
                        password = Console.ReadLine();

                        isAlreadyExist = allPatientDetails
                                .Where(x => x.Name == name && x.Password == password)
                                .Any();
                        if (isAlreadyExist)
                        {
                            if (eachPatient.Name.Equals(name) && eachPatient.Password.Equals(password))
                            {
                                isAlreadyExist = false;
                            }
                        }
                    } while (isAlreadyExist);

                    Console.WriteLine("Enter Age:");
                    tempInput = Console.ReadLine();
                    int age;
                    while (int.TryParse(tempInput, out age) == false || int.Parse(tempInput) <= 0)
                    {
                        if (int.TryParse(tempInput, out age) == false)
                        {
                            Console.WriteLine("Invalid Input!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Age!");
                        }
                        Console.WriteLine("Enter Age:");
                        tempInput = Console.ReadLine();
                    }

                    Console.WriteLine("Enter Gender choice:\n  1.Male\n  2.Female");
                    tempInput = Console.ReadLine();
                    int genderChoice;
                    while (int.TryParse(tempInput, out genderChoice) == false ||
                        (int.Parse(tempInput) != 1 && int.Parse(tempInput) != 2))
                    {
                        if (int.TryParse(tempInput, out genderChoice) == false)
                        {
                            Console.WriteLine("Invalid Input!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid choice!");
                        }
                        Console.WriteLine("Enter Gender choice:\n  1.Male\n  2.Female");
                        tempInput = Console.ReadLine();
                    }
                    eachPatient.Name = name;
                    eachPatient.Password = password;
                    eachPatient.Age = age;
                    eachPatient.Gender = genderChoice == 1 ? GenderOption.Male.ToString() : GenderOption.Female.ToString(); ;
                    editedPatientObj = eachPatient;
                }
            }
            return editedPatientObj;

        }
    }
}
