﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppointmentSystem
{
    class Patient
    {
        public int PatientId { get; }
        private static int _patientId = 100;
        public string Password { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public Patient(string name, int age, int genderChoice, string password) 
        {
            PatientId = _patientId;
            _patientId++;

            Name = name;
            Age = age;
            Gender = genderChoice == 1 ? GenderOption.Male.ToString() : GenderOption.Female.ToString();
            Password = password;
        }
    }

    public enum GenderOption 
    {
        Male,
        Female
    }
}
