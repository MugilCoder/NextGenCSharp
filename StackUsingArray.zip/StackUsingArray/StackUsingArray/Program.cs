﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackUsingArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array;
            int max = 0;
            int topelement = 0;
            int arrIndex = 0;
            int arrIndex1 = 0;
            

           void Stack(int size){

                array = new int[size];
                max = size;

            }

            void Push(int num)
            {
                if (topelement  > max )
                {
                    Console.WriteLine("Stack is Full");

                }
                else
                {
                    topelement++;
                    array[arrIndex] = num;
                    arrIndex++;
                }
               
            }

            void Pop()
            {
                if (topelement == 0)
                {
                    Console.WriteLine("Stack is Empty");
                }
                else
                {
                    array[arrIndex1]=0;
                    arrIndex1++;
                }
            }
            bool Contains(int a)
            {
                if (array.Contains(a))
                {
                  
                    return true;
                }
                else
                {
                    return false;
                }

            }


            Stack(10);
            Push(10);
            Push(20);
            Push(30);
            Push(30);
            Pop();
            Pop();
            Push(10);
            Push(20);
            Push(10);
         
          
            Console.WriteLine(array[0]);
            Console.WriteLine(array[1]);
            
            Console.WriteLine(Contains(20));
            Console.Read();
            


        }
    }
}
