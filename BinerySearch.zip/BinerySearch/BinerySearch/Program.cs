﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinerySearch
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrayList = new int[] { 35, 33, 44, 55, 6, 7, 5, 4, 2, 35, 77 };
            int initaialValue;
            int temp = 0;

            for (int i = 0; i < arrayList.Length; i++)
            {
                initaialValue = arrayList[0];
                for (int j = 1 - 1; j >= 0;)
                {
                    if (initaialValue > arrayList[j + 1])
                    {
                        temp = arrayList[j];
                        arrayList[j] = arrayList[j + 1];
                        arrayList[j + 1] = temp;

                    }
                }

                int search_value(int[] array, int targetedWord)
                {


                    for (int k = 0; i < arrayList.Length; i++)
                    {
                        if (targetedWord == arrayList[i])
                            return (i + 1);
                    }
                    return -1;

                }



            }
        }
    }
}
