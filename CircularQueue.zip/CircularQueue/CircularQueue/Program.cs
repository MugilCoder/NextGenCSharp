﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircularQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] CirQue;
            int max = 0;
            int count = 0;
            int index = 0;

            void Circularque(int size)
            {
                CirQue = new int[size];
                max = size;

            }
            void add(int ad)
            {
                if ( count >max)
                {
                    Console.WriteLine("QueFill");

                }
                else
                {
                    count++;
                    CirQue[index] = ad;
                    index++;
                }

            }
            void Delete(int RemovingElementIndex)
            {
                CirQue[RemovingElementIndex - 1] = 0;

            }
            Circularque(5);
            add(0);
            add(1);
            add(2);
            add(3);
            add(4);

            Delete(4);
            Delete(1);
            Delete(2);

            
            foreach(int a in CirQue)
            {
                Console.WriteLine(a);
            }

            Console.Read();



        }
    }
}
