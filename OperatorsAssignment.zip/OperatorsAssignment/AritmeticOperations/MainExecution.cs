﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AritmeticOperations
{
    class MainExecution
    {

        static void Main(string[] args)
        {
            string input = String.Empty;
            Console.WriteLine("Enter the first integer input:");
            input = Console.ReadLine();
            int firstInput = 0;

            while(int.TryParse(input, out firstInput) == false) 
            {

                Console.WriteLine("Invalid input!");
                Console.WriteLine("Enter the first integer input:");
                input = Console.ReadLine();
            }

            Console.WriteLine("Enter the Second integer input:");
            input = Console.ReadLine();
            int secondInput = 0;

            while (int.TryParse(input, out secondInput) == false)
            {
                Console.WriteLine("Invalid input!");
                Console.WriteLine("Enter the Second integer input:");
                input = Console.ReadLine();
            }

            Console.WriteLine("Enter your choice:\n1.Addition\n2.Subtration\n3.Multiplication\n4.Division\n5.Modulus");
            input = Console.ReadLine();
            int choice = 0;
            while (int.TryParse(input, out choice) == false || int.Parse(input) >5 || int.Parse(input) <1)
            {
                if(int.TryParse(input, out choice) == false) 
                {
                    Console.WriteLine("Invalid Input!");
                }
                else 
                {
                    Console.WriteLine("Invalid Choice!");

                }
                Console.WriteLine("Enter your choice:\n1.Addition\n2.Subtration\n3.Multiplication\n4.Division\n5.Modulus");
                input = Console.ReadLine();
            }
            try 
            {
                int output;
                switch (choice)
                {
                    case 1:
                        output = firstInput + secondInput;
                        Console.WriteLine($"Addition result = {output}");
                        break;


                    case 2:
                        output = firstInput - secondInput;
                        Console.WriteLine($"Subtraction result = {output}");
                        break;


                    case 3:
                        output = firstInput * secondInput;
                        Console.WriteLine($"Multiplication result = {output}");
                        break;


                    case 4:
                        output = firstInput / secondInput;
                        Console.WriteLine($"Division result = {output}");
                        break;


                    case 5:
                        output = firstInput % secondInput;
                        Console.WriteLine($"Modulus result = {output}");
                        break;
                }
                
            }
            catch (Exception ex) 
            {
                Console.WriteLine($"Exception Message = {ex.Message}");
            }

            Console.ReadLine();
        }
    }
}

/*
 1.Write a program to perform the below actions.

Addition
Subtraction
Multiplication
Division
Modulus
 */