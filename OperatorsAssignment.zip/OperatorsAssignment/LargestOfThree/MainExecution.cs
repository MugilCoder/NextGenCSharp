﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LargestOfThree
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any three numbers:");
            int[] storeNumber = new int[3];
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"Enter integer input {i+1}:");
                string input = Console.ReadLine();
                int checkedInput = 0;

                while (int.TryParse(input, out checkedInput) == false)
                {

                    Console.WriteLine("Invalid input!");
                    Console.WriteLine($"Enter the valid integer input {i+1}:");
                    input = Console.ReadLine();
                }
                storeNumber[i] = checkedInput;
            }
            int largestNumber = storeNumber[0];
            for (int i = 0; i < storeNumber.Length; i++)
            {
                if(largestNumber < storeNumber[i]) 
                {
                    largestNumber = storeNumber[i];
                }
            }
            Console.WriteLine($"Largest of all three numbers = {largestNumber}");
            Console.ReadLine();
        }
    }
}
