﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExeceptionTask
{
    class MainExecution
    {
        /*
         1. Create a program to ask the user for two numbers and display their division. 
            Errors must be trapped using “try..catch”.
         */
        static void Main(string[] args)
        {
            string input = string.Empty;
            Console.WriteLine("Enter the first number:");
            input = Console.ReadLine();
            int firstInput = 0;
            while(int.TryParse(input,out firstInput) == false) 
            {
                Console.WriteLine("Invalid integer input!");
                Console.WriteLine("Enter the first number:");
                input = Console.ReadLine();
            }

            Console.WriteLine("Enter the second number:");
            input = Console.ReadLine();
            int secondInput = 0;
            while (int.TryParse(input, out secondInput) == false)
            {
                Console.WriteLine("Invalid integer input!");
                Console.WriteLine("Enter the second number:");
                input = Console.ReadLine();
            }

            try
            {
                int divisionResult = firstInput / secondInput;
                Console.WriteLine($"Quotient = {divisionResult}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Cannot divide a number by Zero!!");
            }
            Console.ReadLine();
        }
    }
}
