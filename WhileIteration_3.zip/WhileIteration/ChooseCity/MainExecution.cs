﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChooseCity
{
    class MainExecution
    {
        /*
         Which city is capital of India?

            Chennai
            Delhi
            Mumbai
            Kolkata
            Enter your choice: 1

            Incorrect!

            Press Y to continue, Press N to close
         */
        static void Main(string[] args)
        {
            string toContinue = "Y";

            while(toContinue == "Y") 
            {
                Console.WriteLine("Which city is capital of India?\n1. Chennai\n2. Delhi\n3. Mumbai\n4. Kolkata\n");
                Console.WriteLine("Enter your choice : ");
                string input = Console.ReadLine();
                int choice = 0;
                while(int.TryParse(input, out choice) == false || int.Parse(input) > 4 || int.Parse(input) < 1) 
                {
                    if(int.TryParse(input, out choice) == false) 
                    {
                        Console.WriteLine("Invalid Input!!");
                    }
                    else 
                    {
                        Console.WriteLine("Invalid Choice!!");
                    }
                    Console.WriteLine("Which city is capital of India?\n1. Chennai\n2. Delhi\n3. Mumbai\n4. Kolkata\n");
                    Console.WriteLine("Enter your choice : ");
                    input = Console.ReadLine();
                }

                if(choice == 2) 
                {
                    Console.WriteLine("Correct !!!");
                }
                else 
                {
                    Console.WriteLine("Incorrect !!!");
                }

                Console.WriteLine("Press Y to continue, Press N to close");
                toContinue = Console.ReadLine().ToUpper();
                while (!toContinue.Equals("Y") && !toContinue.Equals("N"))
                {
                    Console.WriteLine("Invalid choice !!");
                    Console.WriteLine("Press Y to continue, Press N to close");
                    toContinue = Console.ReadLine().ToUpper();
                }
            }

            Console.WriteLine("Process Ended!");
            Console.ReadLine();
        }
    }
}
