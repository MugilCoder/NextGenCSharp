﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsertionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int m = 0;
            int elementtemp = 0;
            int elementtemp2 = 0;
            int[] arrayList = { 10, 5, 6, 7, 4, 2, 3, 1 };
            for(int k = 0; k < arrayList.Length; k++)
            {
                elementtemp = arrayList[k];
                m = k - 1;
                while(m>=0 && elementtemp<arrayList[m])
                {
                    elementtemp2 = arrayList[m];
                    arrayList[m] = arrayList[m + 1];
                    arrayList[m] = elementtemp2;
                    m--;
                }
               
            }
            foreach(int i in arrayList)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();

        }
    }
}
