﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompareGrade
{
    class Program
    {
        /*
         Write a program to get the grade value from user and based on that print the below values.

If Grade is “A”, print “Grade A denotes 9 Points”
If Grade is “B”, print “Grade B denotes 8 Points”
If Grade is “C”, print “Grade C denotes 7 Points”
If Grade is “D”, print “Grade D denotes 6 Points”
If any other word is entered by user, then print “This is not valid Grade”.
         */
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the grade you obtained:");
            string gradeValue = Console.ReadLine().ToUpper();
            if (gradeValue.Equals("A")) 
            {
                Console.WriteLine("Grade A denotes 9 Points");
            }
            else if (gradeValue.Equals("B")) 
            {
                Console.WriteLine("Grade B denotes 8 Points");
            }
            else if (gradeValue.Equals("C")) 
            {
                Console.WriteLine("Grade C denotes 7 Points");
            }
            else if (gradeValue.Equals("D"))
            {
                Console.WriteLine("Grade D denotes 6 Points");
            }
            else 
            {
                Console.WriteLine("This is not a valid Grade");
            }
            Console.ReadLine();
        }
    }
}
