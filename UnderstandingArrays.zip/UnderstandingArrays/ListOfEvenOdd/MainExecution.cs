﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListOfEvenOdd
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the 10 number:");
            int[] storeValues = new int[10];
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter integer input {i + 1}:");
                string input = Console.ReadLine();
                int checkedInput = 0;

                while (int.TryParse(input, out checkedInput) == false)
                {

                    Console.WriteLine("Invalid input!");
                    Console.WriteLine($"Enter the valid integer input {i + 1}:");
                    input = Console.ReadLine();
                }
                storeValues[i] = checkedInput;
            }
            int temp = 0;

            /// Ascending Sort
            
            for (int i = 0; i < storeValues.Length; i++)
            {
                for (int j = i + 1; j < storeValues.Length; j++)
                {
                    if (storeValues[i] > storeValues[j])
                    {
                        temp = storeValues[i];
                        storeValues[i] = storeValues[j];
                        storeValues[j] = temp;
                    }
                }
            }
            
            Console.WriteLine("Even Numbers from Ascending Sort:");
            foreach (int eachValue in storeValues)
            {
                if(eachValue % 2 == 0) 
                {
                    Console.Write(eachValue + " ");
                }
            }

            Console.WriteLine();

            Console.WriteLine("Odd Numbers from Descending Sort:");
            for (int i = storeValues.Length - 1; i >= 0 ; i--)
            {
                if(storeValues[i] % 2 != 0) 
                {
                    Console.Write(storeValues[i] + " ");
                }
            }
            Console.ReadLine();
        }
    }
}
/*
2.Write a program to perform the below operations.

Get the 10 numbers from the user by array
Print the list of even numbers alone by ascending order using array
Print the list of Odd numbers alone by descending order using array
 */
