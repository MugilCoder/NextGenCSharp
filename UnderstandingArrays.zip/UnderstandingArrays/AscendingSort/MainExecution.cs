﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AscendingSort
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the 5 number:");
            int[] storeValues = new int[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Enter integer input {i + 1}:");
                string input = Console.ReadLine();
                int checkedInput = 0;

                while (int.TryParse(input, out checkedInput) == false)
                {

                    Console.WriteLine("Invalid input!");
                    Console.WriteLine($"Enter the valid integer input {i + 1}:");
                    input = Console.ReadLine();
                }
                storeValues[i] = checkedInput;
            }
            int temp = 0;
            for (int i = 0; i < storeValues.Length; i++)
            {
                for (int j = i+1; j < storeValues.Length; j++)
                {
                    if(storeValues[i] > storeValues[j]) 
                    {
                        temp = storeValues[i];
                        storeValues[i] = storeValues[j];
                        storeValues[j] = temp;
                    }
                }
            }
            Console.WriteLine("After Ascending Sorting:");
            foreach (int eachValue in storeValues)
            {
                Console.Write(eachValue+" ");
            }
            Console.ReadLine();
        }
    }
}

/*
 1.Write a program of sorting an array. Declare array and accept 5 integer values from the user. 
Then sort the input in ascending order and display output.

*/