﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelectionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrayList =  { 150,130,100,20,303,333,45,5,2,3 };
            int temp, min;
            for (int i = 0; i < arrayList.Length-1; i++)
            {
                min = i;
                for (int j = i + 1; j < arrayList.Length; j++)
                {
                    if (arrayList[j] < arrayList[min])
                    {
                        min = j;
                    }
                }
                temp = arrayList[min];
                arrayList[min] = arrayList[i];
                arrayList[i] = temp;
            }
            Console.WriteLine();
            Console.WriteLine("Sorted List is");
            foreach(int k in arrayList)
            {
                Console.WriteLine(k);
            }
           
            Console.ReadKey();
        }

    }
}
