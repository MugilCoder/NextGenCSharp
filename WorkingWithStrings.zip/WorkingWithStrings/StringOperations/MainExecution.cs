﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOperations
{
    class MainExecution
    {
        static void Main(string[] args)
        {

            ///    Display the odd number of characters from above string.

            string defaultInput = "Syncfusion".ToLower();
            int count = 0;
            for (int i = 0; i < defaultInput.Length; i++)
            {
                for (int j = 0; j < defaultInput.Length; j++)
                {
                    if(defaultInput[i].Equals(defaultInput[j]) == true) 
                    {
                        count += 1;
                    }
                }
                if(count == 1) 
                {
                    Console.WriteLine(defaultInput[i]);
                }
                count = 0;
            }

            ///     Replace the character n with capital N
          
            defaultInput = "Syncfusion";

            defaultInput = defaultInput.Replace('n', 'N');
            Console.WriteLine($"After replacing = {defaultInput}");

            ///     Display the above string in reverse
            defaultInput = "Syncfusion";

            string reversedString = new string(defaultInput.ToCharArray().Reverse().ToArray());

            Console.WriteLine(reversedString);

            ///     Calculate the length of above string

            Console.WriteLine($"Length of the string = {defaultInput.Length}");

            ///     concatenate the first 4 characters of first string and last 3 characters of second string
            
            Console.WriteLine("Enter the first string input:");
            string first = Console.ReadLine();
            Console.WriteLine("Enter the second string input:");
            string second = Console.ReadLine();

            Console.WriteLine(first.Substring(0,4)+second.Substring(second.Length-3,3));

            ///     Print the words by splitting with comma and print in separate line

            defaultInput = "Chennai,Trichy,Mumbai";
            string[] splittedString = defaultInput.Split(',');
            Console.WriteLine("Output of splitted string:");
            foreach (string eachString in splittedString)
            {
                Console.WriteLine(eachString);
            }
            Console.ReadLine();
        }


    }
}
