﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinearSearch
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] arrayList = { "one", "two", "Syncfusion", "Example" };
            Console.WriteLine("Enter the Word to find");
            string a = Console.ReadLine();

           Console.WriteLine($"Position Of {a } is in :{ LSearch(arrayList, a)}");






             int LSearch(string[] arrayList1, string targetedWord)
            {
                for (int i = 0; i < arrayList.Length; i++)
                {
                    if (targetedWord == arrayList[i])
                        return (i + 1);
                }
                return -1;
            }
            Console.Read();
        }

        
    }
}
