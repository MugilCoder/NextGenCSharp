﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<int> quename = new Queue<int>();
            Queue<int> quename1 = new Queue<int>();
            quename.Enqueue(10);
            quename.Enqueue(15);
            quename.Enqueue(20);
            quename.Clear();
            quename.Enqueue(25);
            quename.Enqueue(30);
            quename.Enqueue(35);
            quename.Enqueue(40);
            quename.Enqueue(50);
            quename.Dequeue();
            quename.Dequeue();
           
            Console.WriteLine(quename.Count());
            Console.WriteLine(quename.Peek());
            Console.WriteLine(quename.Contains(10));
            Console.WriteLine(quename.Contains(20));
            Console.WriteLine(quename.Contains(35));
            Console.WriteLine(quename.Equals(quename1));
            Console.ReadKey();



        }
    }
}
