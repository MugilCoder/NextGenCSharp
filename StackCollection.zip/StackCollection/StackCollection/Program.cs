﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> Stackname = new Stack<int>();
            Stackname.Push(10);
            Stackname.Push(20);
            Stackname.Pop();
            bool a=Stackname.Contains(10);
           int b= Stackname.Count();
            Console.WriteLine($"{a}\n{b}");
            Stackname.Push(20); Stackname.Push(20); Stackname.Push(20);

            foreach(int c in Stackname)
            {
                Console.WriteLine(c);
            }

            Console.Read();

        }
    }
}
