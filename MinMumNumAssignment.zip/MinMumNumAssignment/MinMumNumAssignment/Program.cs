﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinMumNumAssignment
{
    class Program
    {
        static void Main(string[] args)
        {

            /* Algorithm For Min Num
             
             Declare Array with Int DataType
            i<-0
            min <-0
            min<-arr[0]
            min>arr[];
            min=arr[];

            print(min)
             
             
             */




            int[] arr = { 1, 2, 2, 3, 4, 5, 6, 6, 7 };
            int i = 0;
            int min = 0;
            min = arr[0];

            for (i = 1; i < arr.Length; i++)
            {
                if (min > arr[i])
                    min = arr[i];
            }
            Console.WriteLine($"The Min Value of Given String Is:{min}");

            Console.ReadLine();
        }
    }
}
