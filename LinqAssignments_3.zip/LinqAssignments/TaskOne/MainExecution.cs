﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskOne
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            string[] place = { "ABU DHABI", "AMSTERDAM", "ROME", "MADURAI", "LONDON", "NEW DELHI", "MUMBAI", "NAIROBI" };

            Console.WriteLine("Input starting character for the string:");
            char startCharacter = Console.ReadLine()[0];

            Console.WriteLine("Input ending character for the string:");
            char endCharacter = Console.ReadLine()[0];

            IEnumerable<string> result = from specificResult in place.Where(specificplace => specificplace.StartsWith(startCharacter.ToString().ToUpper()) == true && specificplace.EndsWith(endCharacter.ToString().ToUpper()) == true)
                                                    select specificResult;
            foreach (string eachResult in result) 
            {
                Console.WriteLine($"result = {eachResult}");
            }
            Console.ReadLine();
        }
    }
}

/*

1. Write a program in C# to find the string which starts and ends with a specific character.

Input:

ABU DHABI   AMSTERDAM   ROME    MADURAI     LONDON  NEW DELHI   MUMBAI      NAIROBI

Input starting character for the string: M

Input ending character for the string: I
 */
