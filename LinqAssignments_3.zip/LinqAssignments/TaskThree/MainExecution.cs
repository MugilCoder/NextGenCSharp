﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskThree
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            string toContinue = string.Empty;
            do
            {
                Console.WriteLine("--------------------------------------------------------------------------------------");
                Console.WriteLine("\t\t\tMENU");
                Console.WriteLine("--------------------------------------------------------------------------------------");

                Console.WriteLine("Press 1 to Show the list of Trainee Id \n\n" +
                "Press 2 to Show the first 3 Trainee Id using Take\n\n" +
                "Press 3 to show the last 2 Trainee Id using Skip\n\n" +
                "Press 4 to show the count of Trainee\n\n" +
                "Press 5 to show the Trainee Name who are all passed out 2019 or later\n\n" +
                "Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name.\n\n" +
                "Press 7 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark who are all scores\n" +
                "\tthe more than or equal to 4 mark\n\n" +
                "Press 8 to show the unique passed out year using distinct\n\n" +
                "Press 9 to show the total marks of single user (get the Trainee Id from User),\n" +
                "\tif Trainee Id does not exist, show the invalid message\n\n" +
                "Press 10 to show the first Trainee Id and Trainee Name\n\n" +
                "Press 11 to show the last Trainee Id and Trainee Name\n\n" +
                "Press 12 to print the total score of each trainee\n\n" +
                "Press 13 to show the maximum total score\n\n" +
                "Press 14 to show the minimum total score\n\n" +
                "Press 15 to show the average of total score\n\n" +
                "Press 16 to show true or false if any one has the more than 40 score using any()\n\n" +
                "Press 17 to show true of false if all of them has the more than 20 using all()\n\n" +
                "Press 18 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark\n" +
                "\tby show the Trainee Name as descending order and then show the Mark as descending order.");

                Console.WriteLine("--------------------------------------------------------------------------------------");
                Console.WriteLine("Please enter your choice");
                Console.WriteLine("--------------------------------------------------------------------------------------");

                string input = Console.ReadLine();
                int choice = 0;
                while (int.TryParse(input, out choice) == false || int.Parse(input) < 1 || int.Parse(input) > 18)
                {
                    if (int.TryParse(input, out choice) == false)
                    {
                        Console.WriteLine("Invalid Input!");
                    }
                    else
                    {
                        Console.WriteLine("Invalid Choice!");
                    }
                    Console.WriteLine("--------------------------------------------------------------------------------------");
                    Console.WriteLine("\t\t\tMENU");
                    Console.WriteLine("--------------------------------------------------------------------------------------");
                   
                    Console.WriteLine("Press 1 to Show the list of Trainee Id \n\n" +
                    "Press 2 to Show the first 3 Trainee Id using Take\n\n" +
                    "Press 3 to show the last 2 Trainee Id using Skip\n\n" +
                    "Press 4 to show the count of Trainee\n\n" +
                    "Press 5 to show the Trainee Name who are all passed out 2019 or later\n\n" +
                    "Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name.\n\n" +
                    "Press 7 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark who are all scores\n" +
                    "\tthe more than or equal to 4 mark\n\n" +
                    "Press 8 to show the unique passed out year using distinct\n\n" +
                    "Press 9 to show the total marks of single user (get the Trainee Id from User),\n" +
                    "\tif Trainee Id does not exist, show the invalid message\n\n" +
                    "Press 10 to show the first Trainee Id and Trainee Name\n\n" +
                    "Press 11 to show the last Trainee Id and Trainee Name\n\n" +
                    "Press 12 to print the total score of each trainee\n\n" +
                    "Press 13 to show the maximum total score\n\n" +
                    "Press 14 to show the minimum total score\n\n" +
                    "Press 15 to show the average of total score\n\n" +
                    "Press 16 to show true or false if any one has the more than 40 score using any()\n\n" +
                    "Press 17 to show true of false if all of them has the more than 20 using all()\n\n" +
                    "Press 18 to show the Trainee Id, Trainee Name, Topic Name, Exercise Name and Mark\n" +
                    "\tby show the Trainee Name as descending order and then show the Mark as descending order.");
                    Console.WriteLine("--------------------------------------------------------------------------------------");
                    Console.WriteLine("Please enter your choice");
                    Console.WriteLine("--------------------------------------------------------------------------------------");
                    input = Console.ReadLine();
                }

                TraineeData obj = new TraineeData();

                switch (choice)
                {
                    //Press 1 to Show the list of Trainee Id

                    case 1:
                        IEnumerable<string> allTraineeIds = from id in obj.GetTraineeDetails()
                                                            select id.TraineeId;
                        Console.WriteLine("All Trainees Ids:");
                        foreach (string eachId in allTraineeIds)
                        {
                            Console.WriteLine(eachId);
                        }
                        break;

                    // Press 2 to Show the first 3 Trainee Id using Take

                    case 2:
                        IEnumerable<string> firstThreeIds = (from id in obj.GetTraineeDetails()
                                                             select id.TraineeId).Take(3);
                        Console.WriteLine("First 3 Trainees Ids:");
                        foreach (string eachId in firstThreeIds)
                        {
                            Console.WriteLine(eachId);
                        }
                        break;

                    // Press 3 to show the last 2 Trainee Id using Skip

                    case 3:
                        List<TraineeDetails> traineeDetails = obj.GetTraineeDetails();
                        int count = traineeDetails.Count;


                        IEnumerable<string> lastTwoIds = (from id in obj.GetTraineeDetails()
                                                          select id.TraineeId).Skip(count - 2);
                        Console.WriteLine("Last 2 Trainees Ids:");
                        foreach (string eachId in lastTwoIds)
                        {
                            Console.WriteLine(eachId);
                        }
                        break;

                    //Press 4 to show the count of Trainee

                    case 4:
                        IEnumerable<TraineeDetails> allTrainee = obj.GetTraineeDetails();
                        Console.WriteLine($"Total number of trainees = {allTrainee.Count()}");
                        break;

                    //Press 5 to show the Trainee Name who are all passed out 2019 or later

                    case 5:
                        IEnumerable<string> traineeNames = from id in obj.GetTraineeDetails()
                                                           .Where(id => id.YearPassedOut >= 2019)
                                                           select id.TraineeName;
                        Console.WriteLine("Trainee Name who are all passed out 2019 or later are as below as follows:");
                        foreach (string eachTrainee in traineeNames)
                        {
                            Console.WriteLine(" " + eachTrainee);
                        }

                        break;

                    // Press 6 to show the Trainee Id and Trainee Name by alphabetic order of the trainee name.

                    case 6:
                        var idAndNames = obj.GetTraineeDetails()
                            .OrderBy(r => r.TraineeName).Select(p => new { p.TraineeId, p.TraineeName });
                        foreach (var item in idAndNames)
                        {
                            Console.WriteLine(item.TraineeId);
                            Console.WriteLine(item.TraineeName);
                        }
                        break;

                    // Press 7 to show the
                    // Trainee Id,
                    // Trainee Name,
                    // Topic Name,
                    // Exercise Name
                    // Mark
                    // who are all scores the more than or equal to 4 mark

                    case 7:

                        var specificDetails = from allStudents in obj.GetTraineeDetails()
                                              from scores in allStudents.ScoreDetails
                                              where scores.Mark >= 4
                                              select new
                                              {
                                                  Id = allStudents.TraineeId,
                                                  Name = allStudents.TraineeName,
                                                  MarksDetails = scores,
                                                  Marks = scores.Mark,
                                                  Topic = scores.TopicName,
                                                  Excercise = scores.ExerciseName
                                              };
                        foreach (var details in specificDetails)
                        {
                            Console.WriteLine("----------------------------------------------");
                            Console.WriteLine($"ID = {details.Id}  NAME = {details.Name}");
                            Console.WriteLine($"Mark = {details.Marks}\nTopic = {details.Topic}\nExcercise = {details.Excercise}");
                            Console.WriteLine("----------------------------------------------");

                        }
                        break;

                    //Press 8 to show the unique passed out year using distinct

                    case 8:
                        IEnumerable<int> uniqueYears = (from allDetails in obj.GetTraineeDetails()
                                                        select allDetails.YearPassedOut).Distinct();
                        Console.WriteLine("Unique Year Passouts:");
                        foreach (int uniqueEachYear in uniqueYears)
                        {
                            Console.WriteLine(uniqueEachYear);
                        }
                        break;

                    //Press 9 to show the total marks of single user (get the Trainee Id from User),
                    //if Trainee Id does not exist, show the invalid message

                    case 9:
                        Console.WriteLine("Enter trainee ID:");
                        string idFromUser = Console.ReadLine();
                        bool isValidInput = false;

                        var specificStudent = from allDetails in obj.GetTraineeDetails()
                                              where allDetails.TraineeId == idFromUser
                                              from markDetails in allDetails.ScoreDetails
                                              select new
                                              {
                                                  Excercise = markDetails.ExerciseName,
                                                  marks = markDetails.Mark
                                              };

                        foreach (var markDetail in specificStudent)
                        {
                            Console.WriteLine($"{markDetail.Excercise} = {markDetail.marks}");
                            isValidInput = true;
                        }
                        if (isValidInput == false)
                        {
                            Console.WriteLine("Invalid input!!!");
                        }

                        break;

                    //Press 10 to show the first Trainee Id and Trainee Name

                    case 10:
                        var firstIdName = obj.GetTraineeDetails().Select(k => new { k.TraineeId, k.TraineeName }).Take(1);
                        Console.WriteLine("First Trainee Id and Trainee Name");
                        foreach (var item in firstIdName)
                        {
                            Console.WriteLine($"{item.TraineeId} = {item.TraineeName}");
                        }
                        break;

                    // Press 11 to show the last Trainee Id and Trainee Name

                    case 11:
                        var lastIdName = obj.GetTraineeDetails().Select(k => new { k.TraineeId, k.TraineeName }).Skip(obj.GetTraineeDetails().Count - 1);
                        Console.WriteLine("Last Trainee Id and Trainee Name");
                        foreach (var item in lastIdName)
                        {
                            Console.WriteLine($"{item.TraineeId} = {item.TraineeName}");
                        }
                        break;

                    //Press 12 to print the total score of each trainee

                    case 12:
                        var allTraineeScores = from allNames in obj.GetTraineeDetails()
                                               from allScoreDetails in allNames.ScoreDetails
                                               group allScoreDetails by allNames.TraineeName;

                        foreach (var eachTrainee in allTraineeScores)
                        {
                            Console.WriteLine($"Total marks obtained by {eachTrainee.Key} = {eachTrainee.Sum(x => x.Mark)}");

                        }
                        break;

                    //Press 13 to show the maximum total score

                    case 13:
                        int maximumMark = obj.GetTraineeDetails().Select(x => x.ScoreDetails.Sum(u => u.Mark)).Max();
                        Console.WriteLine($"Maximum Total Score = {maximumMark}");

                        break;

                    //Press 14 to show the minimum total score

                    case 14:
                        int minimumMark = obj.GetTraineeDetails().Select(k => k.ScoreDetails.Sum(y => y.Mark)).Min();
                        Console.WriteLine($"Minimum Total Score = {minimumMark}");
                        break;

                    //Press 15 to show the average of total score

                    case 15:
                        double avergeMark = obj.GetTraineeDetails().Select(x => x.ScoreDetails.Sum(z => z.Mark)).Average();
                        Console.WriteLine($"Average of Total Score = {avergeMark}");
                        break;

                    //Press 16 to show true or false if any one has the more than 40 score using any()

                    case 16:
                        bool isRequiredScore = obj.GetTraineeDetails().Select(x => x.ScoreDetails.Sum(y => y.Mark)).Any(x => x > 40);
                        Console.WriteLine($"Is any one candidate total score is greater than 40 :{isRequiredScore}");
                        break;

                    //Press 17 to show true of false if all of them has the more than 20 using all()

                    case 17:
                        bool isAllRequiredScore = obj.GetTraineeDetails().Select(x => x.ScoreDetails.Sum(y => y.Mark)).All(x => x > 20);
                        Console.WriteLine($"Does all candidates total score atleast greater than 20 :{isAllRequiredScore}");
                        break;

                    // Press 18 to show
                    // Trainee Id,
                    // Trainee Name,
                    // Topic Name,
                    // Exercise Name
                    // Mark
                    // by show the Trainee Name as descending order
                    // and
                    // then show the Mark as descending order.

                    case 18:
                        var detailSpecific = obj.GetTraineeDetails()
                            .Select(y =>
                            new
                            {
                                id = y.TraineeId,
                                name = y.TraineeName,
                                scoreDetails = y.ScoreDetails.OrderByDescending(b => b.Mark)
                            }).OrderByDescending(h => h.name);
                        foreach (var eachTrainee in detailSpecific)
                        {
                            Console.WriteLine("-------------------------------------------------------------------------------");
                            Console.WriteLine($"Id = {eachTrainee.id}\tName = {eachTrainee.name}");
                            foreach (var score in eachTrainee.scoreDetails)
                            {
                                Console.WriteLine($"Topic Name = {score.TopicName}\t\tExercise = {score.ExerciseName}\tMark = {score.Mark}\t");
                            }
                            Console.WriteLine("-------------------------------------------------------------------------------");

                        }
                        break;

                    default:
                        break;
                }
                Console.WriteLine("Do you want to continue? (yes/no)");
                toContinue = Console.ReadLine().ToLower();
                while(!toContinue.Equals("yes") && !toContinue.Equals("no")) 
                {
                    Console.WriteLine("Invalid choice!");
                    Console.WriteLine("Do you want to continue? (yes/no)");
                    toContinue = Console.ReadLine().ToLower();
                }
            } while (toContinue.Equals("yes"));
            Console.ReadLine();

        }
    }
}
