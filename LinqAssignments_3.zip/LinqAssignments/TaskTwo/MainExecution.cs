﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskTwo
{
    class MainExecution
    {
        /*
         2. Write a program in C# to display the list of items in the array according to the length of the string then by name in ascending order.

Input:

ABU DHABI

AMSTERDAM

ROME

PARIS

CALIFORNIA

LONDON

NEW DELHI

ZURICH

NAIROBI
       
         */
        static void Main(string[] args)
        {
            string[] place = { "ABU DHABI", "AMSTERDAM", "ROME", "PARIS", "CALIFORNIA", "LONDON", "NEW DELHI","ZURICH", "NAIROBI" };
            IEnumerable<string> result = place.OrderBy(sortedResult => sortedResult.Length).ThenBy(sortedResult => sortedResult);
                                         
            Console.WriteLine("Output :");
            foreach (string eachResult in result)
            {
                Console.WriteLine(eachResult);
            }
            Console.ReadLine();
        }
    }
}
