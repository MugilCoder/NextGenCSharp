﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Value");
            int value = int.Parse(Console.ReadLine());
            Console.WriteLine(Factorial(value));
            
           
            Console.WriteLine(value);


           int  Factorial(int a)
            {
                if (a == 0)
                {
                    return 1;
                }
                else
                {
                    return Factorial(a) * Factorial(a - 1);
                }

            }

           
            Console.Read();
        }
    }
}
