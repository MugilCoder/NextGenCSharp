﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumAverage
{
    class MainExecution
    {
        static void Main(string[] args)
        {
            int sum = 0;
            Console.WriteLine("Enter the 10 number:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Enter integer input {i + 1}:");
                string input = Console.ReadLine();
                int checkedInput = 0;

                while (int.TryParse(input, out checkedInput) == false)
                {

                    Console.WriteLine("Invalid input!");
                    Console.WriteLine($"Enter the valid integer input {i + 1}:");
                    input = Console.ReadLine();
                }
                sum += checkedInput;
            }
            Console.WriteLine($"The sum of 10 number is: {sum}");
            Console.WriteLine($"The average is: {sum/10}");

            Console.ReadLine();
        }
    }
}
